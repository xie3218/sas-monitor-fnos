# SAS 硬盘管理 0.1.6

飞牛 fnOS 的 SAS 硬盘监控应用。它在上次采集完成约 5 分钟后再次采集 SMART 数据。桌面应用复用飞牛登录态，只允许管理员查看，网页本身以飞牛应用账户运行。

## 从旧版升级

1. 在飞牛「应用中心 → 手动安装」上传新版 `sas-monitor.fpk`。
2. 把新版 `collector/` 上传到 NAS，SSH 进入该目录，运行 `sudo bash ./install.sh` 更新采集服务。首次成功读取每块盘的计数时会建立基线。已运行 0.1.5 采集服务时，可直接执行下一步。
3. 关闭并重新打开飞牛桌面里的应用窗口，点击「立即采集」。

## 安装

1. 解压安装包，在飞牛「应用中心 → 手动安装」上传 `sas-monitor.fpk`。该包需使用支持统一网关的 fnOS，桌面入口使用当前飞牛地址。
2. 上传解压后的 `collector/` 到 NAS。在 NAS SSH 终端进入它的上级目录，按顺序执行下面的命令。如果 `smartctl` 和 `/usr/bin/python3` 已存在，可直接执行第二条。

   ```bash
   sudo apt install smartmontools python3
   sudo bash collector/install.sh
   ```

3. 回到飞牛桌面，打开「SAS 硬盘管理」。首次采集取决于硬盘数量和控制器响应时间。页面每 30 秒读取一次后台结果。点击「立即采集」会请求 NAS 重新读取 SMART 数据，界面会显示采集结果。

## 界面能看什么

宽窗口并排显示列表和详情，中等窗口上下排列，窄窗口把硬盘表格转换成卡片。顶部栏、统计卡片、硬盘列表和详情使用固定浅色的毛玻璃主题，搭配冰蓝和薄荷绿底色。浏览器不支持背景模糊或系统启用减少透明度时，使用实色面板。

- 设备名、型号、序列号、WWN、固件、容量、逻辑及物理扇区大小。
- SMART 总体状态、温度、通电时间、G-list 增长缺陷项数。
- 读、写、校验的已纠正及不可纠正错误，非介质错误及 SMART 自检历史。
- 点击硬盘行跳转到详情，或使用详情里的「切换硬盘」。自动刷新后会尽量保留当前选择。
- 支持按状态筛选，并将所有硬盘的清单和计数导出成 CSV。单盘仍可导出原始 SMART 文本。
- 页面中「—」表示设备没有提供该字段。

硬盘上报 SMART 失败时显示「SMART 故障」。G-list 大于零、存在不可纠正错误或自检日志有失败记录仍可触发「需关注」。

非介质错误按 WWN 追踪，缺少 WWN 时用型号和序列号。首读建立基线，旧累计值会展示。只在观测到新增加后维持 24 小时的「需关注」提示。计数回落时重新建立基线。增量和触发原因会显示在详情及导出的 CSV 中。基线保存在 NAS 本机，系统重启后可以继续对比。应用所用的 SMART 查询可能唤醒休眠盘。

## 兼容范围

首版面向可透传 SAS 查询的 HBA，例如 IT 模式的 LSI/Broadcom 控制器。硬 RAID 场景会尝试 smartctl 自动枚举出的 MegaRAID 物理盘。实际结果取决于驱动、固件及 smartctl 是否能访问物理盘并确认其 SAS 协议。PVE 虚拟机运行 fnOS 时，需要让 fnOS 能直接看到 HBA 或可透传的物理设备。

本版本为只读监控。历史自检记录由硬盘提供。已用模拟数据验证多盘功能与手动采集的请求、结果更新和错误提示。新版安装及 systemd 在飞牛真机上的联动仍需验证。

## 诊断

```bash
sudo smartctl --scan-open
sudo systemctl status sas-monitor-collector.path --no-pager
sudo systemctl start sas-monitor-collector.service
sudo journalctl -u sas-monitor-collector.service -n 50 --no-pager
```

硬盘路径和 `-d` 参数从扫描输出取值。以扫描到 `/dev/sda -d scsi` 为例：

```bash
sudo smartctl -x -d scsi /dev/sda
```

如果桌面入口返回 502，可查看 `/var/apps/sas-monitor/var/web.log`，并确认当前 fnOS 支持统一网关。本应用只监听本地 Unix Socket，通过系统代理身份和飞牛管理员请求头限制访问。

## 卸载与重打包

先在 NAS 执行 `sudo bash collector/uninstall.sh`，再从应用中心卸载「SAS 硬盘管理」。

`fpk/` 为飞牛应用源码，`collector/` 为本机采集器源码。在 `fpk/` 下使用飞牛官方 `fnpack build` 可以重新打包。
